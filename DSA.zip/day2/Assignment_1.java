package day2;

//Take sorted array with duplicates.Find First Occurance of target
public class Assignment_1 {

	public static void main(String[] args) {

		int[] arr = { 1, 1, 2, 2, 2, 3, 3, 3, 4, 5 };
		int target = 3;

		//int index = firstOccuranceOfTarget(arr, target);
		//int index1 = lastOccuranceOfTarget(arr, target);
		//int index3 = totalNumberOfOccurance(arr, target);
		int index4 = firstOccuranceOfTargetBs(arr, target);// binary search
		//System.out.println("Found target at index: " + index);
		//System.out.println("Found target at index: " + index1);
		System.out.println("Found target at index: " + index4);
	}

	// binary search
	private static int firstOccuranceOfTargetBs(int[] arr, int target) {
		int left = 0;
		int right = arr.length - 1;
int result=-1;
		while (left <=right) {
			int mid = left + (right - left) / 2;
			
			if (arr[mid] == target) {
				result= mid;//store the current position
				 right = mid - 1;//to check if element is present previous
			}
			else if ( arr[mid]<target) {
				left = mid + 1;
			} else {
				right = mid - 1;
			}

		}
		return result;
	}
/*
//linear search
	private static int totalNumberOfOccurance(int[] arr, int target) {

		return -1;
	}

	private static int firstOccuranceOfTarget(int[] arr, int target) {
		// linear search
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == target) {

				return i;
			}
		}
		return -1;
	}
	// linear search

	private static int lastOccuranceOfTarget(int[] arr, int target) {
		for (int i = arr.length - 1; i > 0; i--) {
			if (arr[i] == target) {
				return i;
			}

		}
		return -1;
	}
*/
}
