package day2;

public class BinarySearch {

	public static void main(String[] args) {

		int arr[] = { 2, 6, 8, 12, 45, 89, 94, 96, 67, 98 };
		int target = 98;

		int index = binarySearch(arr, target);
		System.out.println("Found target at index: " + index);

	}

	
	private static int binarySearch(int[] arr, int target) {

		int left = 0;
		int right = arr.length - 1;// if we do not take -1 it will throw ArrayOutOfBoundException

		while (left <= right) {
			int mid = left + (right - left) / 2;

			if (arr[mid] == target) {
				return mid;
			}
			if (target < arr[mid]) {

				right = mid - 1;
			} else {
				left = mid + 1;
			}
		}

		return -1;// -1 indicates Element not found
	}

}
