package day2;

import java.util.Arrays;

public class BubbleSort {

	public static void main(String[] args) {
		int arr[] = { 5, 3, 8, 4, 2 };

		int n = arr.length;
		boolean swapped = false;

		for (int i = 0; i < n - 1; i++) // Number of passes

		{
			System.out.println("No of passes: " + i);
			swapped = false;
			// we took -1 here that why we cannot get ArrayOutOfBoundException
			for (int j = 0; j < n - i - 1; j++) // no of comparisons
			{
				if (arr[j] > arr[j + 1]) {
//swap
					int temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
					swapped = true;
				}
			}
			if (!swapped) // if no swapped, then break out of outer loop
			{
				break;
			}
		}

		System.out.println(Arrays.toString(arr));
	}

}
