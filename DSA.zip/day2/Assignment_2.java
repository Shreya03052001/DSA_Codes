package day2;
//using binary search
//Take sorted array with duplicates.Find Last Occurance of target

public class Assignment_2 {
public static void main(String[] args) {
	int [] arr= {1,2,2,2,3,4,5};
	int target=3;
	int index=lastOccuranceOfTarget(arr,target);
	System.out.println("Found target at index: " + index);

	}
private static int lastOccuranceOfTarget(int[] arr, int target) {
		int left=0;
		int right=arr.length-1;
		int result=-1;
		while(left<=right) {
			int mid=left+(right-left)/2;
			if(arr[mid]==target) {
				result=mid;
				left=mid+1;//search on right side
			}
			else if(arr[mid]<target) {
				left=mid+1;
				
				
			}else {
				right=mid-1;
			}
		}
			return result;
	}

}
