package day2;
//Binary search
//Take sorted array with duplicates.Find Total no of Occurance of target

public class Assignment_3 {

	public static void main(String[] args) {
		int [] arr= {1,2,2,2,3,4,5};
		int target=3;
		int index = firstOccuranceOfTarget(arr, target);// binary search
		System.out.println("Found target at index: " + index);
		int index1=lastOccuranceOfTarget(arr,target);
		System.out.println("Found target at index: " + index1);
		
		//count of occurance
		int index2=countOfTotalOccurance(arr,target);
		System.out.println("Total no of occurance: "+index2);

	}

	
	private static int countOfTotalOccurance(int[] arr, int target) {
		int first =firstOccuranceOfTarget(arr,target);
		if(first==-1) {
			return 0;
			
		}
		int last=lastOccuranceOfTarget(arr,target);
		return last-first+1;
	}


	private static int firstOccuranceOfTarget(int[] arr, int target) {
		int left = 0;
		int right = arr.length - 1;
int result=-1;
		while (left <=right) {
			int mid = left + (right - left) / 2;
			
			if (arr[mid] == target) {
				result= mid;//store the current position
				 right = mid - 1;//to check if element is present previous
			}
			else if ( arr[mid]<target) {
				left = mid + 1;
			} else {
				right = mid - 1;
			}

		}
		return result;
	
	}
	private static int lastOccuranceOfTarget(int[] arr, int target) {
		int left=0;
		int right=arr.length-1;
		int result=-1;
		while(left<=right) {
			int mid=left+(right-left)/2;
			if(arr[mid]==target) {
				result=mid;
				left=mid+1;//search on right side
			}
			else if(arr[mid]<target) {
				left=mid+1;
				
				
			}else {
				right=mid-1;
			}
		}
			return result;
	
	}


}
